CNT 5106 Computer Networks Project 1
Implementation of FTP client and server

Steps to run the project:

1)Go to D:\Demo\Server in the command terminal and compile by: python server.py

2)Go to D:\Demo\Client 1 in the command terminal and compile by: python client.py (Similar for Client 2)

3)Then login via 'ftpclient 172.16.105.58'. (The IP address '172.16.105.58' and the Port '21' are hard coded within server.py)

4)Enter Username as 'prakhar' and Password as 'mittal' (Again, hard coded within server.py)

5)After successfull connection, you can now use commands:
  'dir'
  'get<filename>'
  'upload<filename>'
  'quit'   

Note: The Server files are stored in the server folder.

