from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

authorizer = DummyAuthorizer()

authorizer.add_user("prakhar", "mittal", "D:\Demo\Server", perm="elradfmwMT")

authorizer.add_anonymous("D:\Demo\Server")
handler = FTPHandler
handler.authorizer = authorizer
server = FTPServer(("172.16.105.58", 21), handler)
server.serve_forever()